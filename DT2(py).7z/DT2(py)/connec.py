from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import mysql.connector
from mysql.connector import Error
import datetime
import json
from contextlib import closing


app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Needed for flashing messages

# MySQL Database Configuration
DB_NAME = "defaultdb"
DB_HOST = "mysql-1f4c3a5e-testforfun95-f2cf.i.aivencloud.com"
DB_USER = "avnadmin"
DB_PASS = "AVNS_EUYMQpuX49ucPjRKKXU"
DB_PORT = 16183

def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            database=DB_NAME,
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASS,
            port=DB_PORT
        )
        if connection.is_connected():
            print("Connected to MySQL Server")
            cursor = connection.cursor()
            # Create items table if it does not exist
            cursor.execute(""" 
            CREATE TABLE IF NOT EXISTS items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                weight DECIMAL(10, 2),
                price DECIMAL(10, 2) NOT NULL
            )
            """)

            # Create items table if it does not exist
            cursor.execute(""" 
            CREATE TABLE IF NOT EXISTS inventory (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                weight DECIMAL(10, 2),
                price DECIMAL(10, 2) NOT NULL
            )
            """)


            # Create purchase_history table if it does not exist
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS purchase_history (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                quantity INT NOT NULL,
                unit VARCHAR(50),
                total_price DECIMAL(10, 2) NOT NULL,
                purchase_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """)
            connection.commit()
    except Error as e:
        print(f"The error '{e}' occurred")
    return connection

# Initialize MySQL connection
connection = create_connection()

# Route for displaying the login page
@app.route('/')
def login():
    return render_template('login.html')

# Route for handling form submission
@app.route('/login', methods=['POST'])
def handle_login():
    username = request.form['username']
    password = request.form['password']
    
    # Example authentication logic
    if username == 'admin' and password == 'admin123':
        return redirect(url_for('admin_home'))

    elif username == 'staff' and password == 'user123':
        return redirect(url_for('index'))
    else:
        return "Invalid credentials, please try again."
    
# Route for user home page (inventory app)
@app.route('/index')
def index():
    return render_template('index.html')

# Route for adding items (showing the dropdown)
@app.route('/add', methods=['GET'])
def add_item():
    # Connect to the database and fetch item names, weights, and prices
    conn = create_connection()
    items = []
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name, weight, price FROM items")  # Fetch names, weights, and prices
            items = cursor.fetchall()  # Get all results
            
            # Convert tuples to a list of dictionaries for easier access in the template
            items = [{'name': item[0], 'weight': item[1], 'price': item[2]} for item in items]
            
        except Exception as e:
            return f"An error occurred: {e}"
        finally:
            cursor.close()
            conn.close()
    else:
        return "Failed to connect to the database."
    
    return render_template('add.html', items=items)

# Route for adding new items to the database
@app.route('/add_items', methods=['POST'])
def add_items():
    # You can perform any necessary operations here, if needed
    flash("Item successfully added!")  # Flash the success message
    return redirect(url_for('add_item'))  # Redirect back to the add item page

# Route for confirming items
@app.route('/confirm', methods=['GET', 'POST'])
def confirm_item():
    # Instead of fetching from the database, we can rely on the data passed from local storage
    return render_template('confirm.html')  # Render the confirm page directly without any data fetching

# Route for billing
@app.route('/bill', methods=['GET'])
def bill():
    return render_template('bill.html')  # Render the billing page


# Route for the admin home page
@app.route('/admin_home')
def admin_home():
    return render_template('admin_home.html')

# Route for viewing inventory
@app.route('/view_inventory')
def view_inventory():
    return render_template('item.html')



@app.route('/admin_add_items', methods=['GET', 'POST'])
def admin_add_items():
    if request.method == 'POST':
        item_name = request.form['name']
        item_weight = request.form['weight']
        item_price = request.form['price']
        
        cursor = connection.cursor()
        try:
            # Insert data into the items table
            cursor.execute("INSERT INTO items (name, weight, price) VALUES (%s, %s, %s)", 
                           (item_name, item_weight, item_price))
            
            # Insert data into the inventory table simultaneously
            cursor.execute("INSERT INTO inventory (name, weight, price) VALUES (%s, %s, %s)", 
                           (item_name, item_weight, item_price))
            
            connection.commit()
            flash("Item successfully added!")  # Flash the success message
        except Error as e:
            print(f"The error '{e}' occurred")
            flash("An error occurred while adding the item.")  # Flash error message
        finally:
            cursor.close()
        
        return redirect(url_for('admin_add_items'))  # Redirect to the same page after submission

    # Fetch all items to display in the table
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    cursor.close()
    
    return render_template('admin.html', items=items)  # Render the admin.html page with items data


# Route for removing an item from the database
@app.route('/remove_item/<int:item_id>', methods=['POST'])
def remove_item(item_id):
    # Create a new connection for this operation
    conn = create_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM items WHERE id = %s", (item_id,))
            conn.commit()  # Commit the change
            flash(f"Item with ID {item_id} removed successfully.")
        except Exception as e:
            flash(f"An error occurred: {e}")
        finally:
            cursor.close()  # Always close the cursor
            conn.close()    # Close the connection after the operation
    else:
        flash("Failed to connect to the database.")
    
    return redirect(url_for('admin_add_items'))



@app.route('/view_purchase_history')
def view_purchase_history():
    conn = create_connection()
    cursor = conn.cursor()
    
    # Retrieve purchase history from the database
    cursor.execute("SELECT name, quantity, unit, total_price, purchase_date FROM purchase_history ORDER BY purchase_date DESC")
    purchases = cursor.fetchall()
    
    # Convert to a list of dictionaries for rendering
    purchase_list = [
        {
            'name': purchase[0],
            'quantity': purchase[1],
            'unit': purchase[2],
            'total_price': purchase[3],
            'purchase_date': purchase[4]  # Assuming this is a datetime object
        }
        for purchase in purchases
    ]

    cursor.close()
    conn.close()
    
    return render_template('view_purchase.html', purchases=purchase_list)

@app.route('/update_purchase_history', methods=['POST'])
def update_purchase_history():
    try:
        data = request.get_json()
        confirmed_items = data.get('items', [])
        discounted_total_price = data.get('discountedTotalPrice')  # Corrected to match the incoming data
        amount_received = data.get('amountReceived')  # Fetching the amount received
        purchase_date = data.get('purchaseDate')  # Receive the purchase date

        # Establishing the connection using a context manager
        with closing(create_connection()) as conn:
            with closing(conn.cursor()) as cursor:
                # Insert each item in the purchase history
                for item in confirmed_items:
                    cursor.execute("""
                        INSERT INTO purchase_history (name, quantity, unit, total_price, amount_received, purchase_date)
                        VALUES (%s, %s, %s, %s, %s, %s)
                    """, (item['name'], item['quantity'], item['unitPrice'], item['totalPrice'], amount_received, purchase_date))

                # Commit the transaction
                conn.commit()

        return jsonify({'message': 'Purchase history updated successfully.'}), 200
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({'message': 'Failed to update purchase history.', 'error': str(e)}), 500

@app.route('/clear_purchase_history', methods=['POST'])
def clear_purchase_history():
    conn = create_connection()
    cursor = conn.cursor()
    
    cursor.execute("DELETE FROM purchase_history")
    conn.commit()
    
    cursor.close()
    conn.close()
    
    return redirect(url_for('view_purchase_history'))

@app.route('/current_inventory')
def current_inventory():
    conn = create_connection()
    cursor = conn.cursor()

    # Retrieve sold items from the inventory_sold table
    cursor.execute("SELECT name, price, weight FROM inventory")
    inventory = cursor.fetchall()

    # Convert to a list of dictionaries for rendering
    inventory_list = [
        {
            'name': item[0],
            'price': item[1],
            'weight': item[2],
        }
        for item in inventory
    ]

    cursor.close()
    conn.close()

    return render_template('inventory.html', inventory=inventory_list)




if __name__ == '__main__':
    app.run(debug=True)
