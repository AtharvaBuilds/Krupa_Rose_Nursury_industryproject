from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)

# MySQL Database Configuration
DB_NAME = "defaultdb"
DB_HOST = "mysql-1f4c3a5e-testforfun95-f2cf.i.aivencloud.com"
DB_USER = "avnadmin"
DB_PASS = "AVNS_EUYMQpuX49ucPjRKKXU"
DB_PORT = 16183

# Connect to MySQL Database and create a new database if it doesn't exist
def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            database=DB_NAME,
            host=DB_HOST,
            user=DB_USER,
            password=DB_PASS,
            port=DB_PORT
        )
        if connection.is_connected():
            print("Connected to MySQL Server")
            cursor = connection.cursor()
            # Create database if it does not exist
            cursor.execute("CREATE DATABASE IF NOT EXISTS defaultdb")
            cursor.execute("USE defaultdb")  # Use the created database

            # Create items table if it does not exist
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS items (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                weight DECIMAL(10, 2),
                price DECIMAL(10, 2) NOT NULL
            )
            """)
            connection.commit()
    except Error as e:
        print(f"The error '{e}' occurred")
    return connection

# Initialize MySQL connection
connection = create_connection()

# Route for displaying the login page
@app.route('/')
def login():
    return render_template('login.html')

# Route for handling form submission
@app.route('/login', methods=['POST'])
def handle_login():
    username = request.form['username']
    password = request.form['password']
    
    # Example authentication logic
    if username == 'admin' and password == 'admin123':
        return redirect(url_for('admin_home'))
    elif username=='user' and password == 'user123':
        return redirect(url_for('index'))
    else:
        return "Invalid credentials, please try again."
    
# Route for user confirm page(inventory app)
@app.route('/confirm_item')
def confirm_item():
    return render_template('confirm.html')

# Route for user home page (inventory app)
@app.route('/index')
def index():
    return render_template('index.html')

# Route for adding items (add.html)
@app.route('/add')
def add_item():
    return render_template('add.html')

# Route for billing page
@app.route('/bill')
def bill():
    return render_template('bill.html')

# Route for the admin home page
@app.route('/admin_home')
def admin_home():
    return render_template('admin_home.html')

@app.route('/add', methods=['GET', 'POST'])
def add():
    # Connect to the database and fetch item names
    conn = create_connection()
    item_names = []
    # if conn:
    #     try:
    #         cursor = conn.cursor()
    #         cursor.execute("SELECT name FROM items")  # Fetch only the names from the items table
    #         item_names = [item[0] for item in cursor.fetchall()]  # Extract the names from tuples and convert them to a list
            
    #     except Exception as e:
    #         return f"An error occurred: {e}"
    #     finally:
    #         cursor.close()
    #         conn.close()
    # else:
    #     return "Failed to connect to the database."
    
    # return render_template('add.html', items=item_names)


# Route for adding items
@app.route('/admin_add_items', methods=['GET', 'POST'])
def admin_add_items():
    if request.method == 'POST':
        item_name = request.form['name']
        item_weight = request.form['weight']
        item_price = request.form['price']
        
        # Insert data into the database
        cursor = connection.cursor()
        cursor.execute("INSERT INTO items (name, weight, price) VALUES (%s, %s, %s)", 
                       (item_name, item_weight, item_price))
        connection.commit()
        cursor.close()
        
        return redirect(url_for('admin_add_items'))  # Redirect to the same page after submission

    # Fetch all items to display in the table
    cursor = connection.cursor()
    cursor.execute("SELECT * FROM items")
    items = cursor.fetchall()
    cursor.close()
    
    return render_template('admin.html', items=items)  # Render the admin.html page with items data

# Route for viewing inventory
@app.route('/view_inventory')
def view_inventory():
    return render_template('item.html')

# Route for viewing purchase history
@app.route('/view_purchase_history')
def view_purchase_history():
    return render_template('view_purchase.html')

if __name__ == '__main__':
    app.run(debug=True)
